package com.hk;

import javax.swing.*;
import java.awt.event.*;

public class OutputView extends JFrame implements ActionListener,ItemListener {
	CalculateScoreUtil ccsu=new  CalculateScoreUtil();
	
	JMenuBar jmb=new JMenuBar();
	JMenu jmStart=new JMenu("��ʼ(Start)");
	JMenu jmHelp=new JMenu("����(Help)");
	JMenuItem jmStore=new JMenuItem("��������(Store)");
	JMenuItem jmiExit=new JMenuItem("�˳�ϵͳ(Exit)");
	JLabel jltitle=new JLabel("�˶������ͳ��ϵͳ");
	JLabel jlSort=new JLabel("����ʽ");
	JButton jbSort=new JButton("����");
	JButton jbSearch=new JButton("����");
	JTextArea  jaSort=new JTextArea (3,20);
//	JScrollPane scroll=new JScrollPane(jaSort);
	
	ButtonGroup bgSort=new ButtonGroup();
	JRadioButton [] jrbSort={new JRadioButton("ѧУ���"),new JRadioButton("ѧУ�ܷ�"),
			new JRadioButton("�������ܷ�"),new JRadioButton("Ů�����ܷ�")};
	JLabel jlSearch=new JLabel("��ѯ");
	JComboBox jcbSearch=new JComboBox(new String[]{"ѧУ���","��Ŀ���"});
	JTextField jtfSearch=new JTextField("0");
	
	public OutputView()
	{
		calculate();
		
		this.setTitle("�˶������ͳ��ϵͳ");
		
		this.add(jltitle);
		this.add(jlSort);
		this.add(jbSort);
		this.add(jaSort);
		this.add(jcbSearch);
		this.add(jtfSearch);
		this.add(jlSearch);
		this.add(jbSearch);
//		this.add(scroll);
		this.setJMenuBar(jmb);
		
		jmb.add(jmStart);
		jmb.add(jmHelp);
		jmStart.add(jmStore);
		
		jmStart.add(jmiExit);
		
		for(int i=0;i<jrbSort.length;i++)
		{
			this.add(jrbSort[i]);
			bgSort.add(jrbSort[i]);
			jrbSort[i].setBounds(50,150+40*i,100,20);
			jrbSort[i].addItemListener(this);
		}
		jrbSort[0].setSelected(true);
		
//		scroll.setHorizontalScrollBarPolicy( 
//				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED); 
//		scroll.setVerticalScrollBarPolicy( 
//				JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED); 
		
		jltitle.setBounds(300,0,600, 100);
		jlSort.setBounds(60,100,100,20);
		jbSort.setBounds(50, 320, 100, 20);
		jaSort.setBounds(180,100,300,240);
		jlSearch.setBounds(520,100,100,20);
		jcbSearch.setBounds(500,150,100,20);
		jbSearch.setBounds(620, 150, 100, 20);
		jtfSearch.setBounds(500,200,100,20);
		
		jmiExit.addActionListener(this);
		jbSort.addActionListener(this);
		jbSearch.addActionListener(this);
		jmStore.addActionListener(this);
		
		jaSort.setLineWrap(true);
		jaSort.setEditable(false);
		this.setLayout(null);
		this.setBounds(100,100,770,450);
		this.setVisible(true);
		this.setResizable(false);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==jmiExit)
		{
			this.dispose();
		}else if(e.getSource()==jbSort)
		{
			String str="";
			for(School school:Constant.listSchool)
			{
				str+="ѧУ���:"+school.num+"  ѧУ����:"+school.name+"  ѧУ�ܷ�:"+school.score+"  �����ܷ�:"+school.maleScore+"  Ů���ܷ�"+school.femaleScore+"\n";
			}
			str+="=============================\n";
			jaSort.setText(str);
		}
		else if(e.getSource()==jbSearch)
		{
			int num=-1;
			try{
				num=Integer.parseInt(jtfSearch.getText());
				
				if(num>=0)
				{
					String str="";
					switch(jcbSearch.getSelectedIndex())
					{
						case 0:
							ccsu.sortSchoolId();
							School school=Constant.listSchool.get(num);
							str+="ѧУ���:"+school.num+"  ѧУ����:"+school.name+"  ѧУ�ܷ�:"+school.score+"  �����ܷ�:"+school.maleScore+"  Ů���ܷ�"+school.femaleScore+"\n";
							System.out.println("num="+num);
							break;
						case 1:
							SportsProject sp=null;
							if(num>=0&&num<Constant.listSportsProjectMale.size())
							{
								sp=Constant.listSportsProjectMale.get(num);
							}else if(num<Constant.listSportsProjectMale.size()+Constant.listSportsProjectFemale.size())
							{
								sp=Constant.listSportsProjectFemale.get(num-Constant.listSportsProjectMale.size());
							}
							try{
								int index=sp.scoreSchool[0];
								switch(index)
								{
									case 0:
										for(int j=0;j<3;j++)
										{
											str+="��"+j+"��:"+sp.scoreSchool[j+1]+"  �÷�:"+sp.score[j]+"\n";
										}
										break;
									case 1:
										for(int j=0;j<5;j++)
										{
											str+="��"+j+"��:"+sp.scoreSchool[j+1]+"  �÷�:"+sp.score[j]+"\n";
										}
										break;
								}
							}catch(Exception exception)
							{
								System.out.println("alert");
							}
							
							
							break;
						}
					str+="=============================\n";
					jaSort.setText(str);
				}
			}catch(Exception exception)
			{
				System.out.println("alert");
				exception.printStackTrace();
			}
		}else if(e.getSource()==jmStore)
		{
			String filePath="D://data//output.txt";
			String str="";
			CalculateScoreUtil cs=new CalculateScoreUtil();
			cs.sortSchoolId();
			str+="=======================��Ŀ��Ϣ======================\n";
			str+="��Ŀ����="+(Constant.listSportsProjectMale.size()+Constant.listSportsProjectFemale.size())+"\n";
			str+="������Ŀ����="+Constant.listSportsProjectMale.size()+"   Ů����Ŀ����"+Constant.listSportsProjectFemale.size()+"\n";
			str+="��Ŀ����:(ѧУ���  ��Ŀ�÷�)\n";
			for(int i=0;i<Constant.listSportsProjectMale.size();i++)
			{
				SportsProject sp=Constant.listSportsProjectMale.get(i);
				str+="��Ŀ���:"+i+"   "+"��Ŀ����:"+sp.name+"\n";
				int index=sp.scoreSchool[0];
				switch(index)
				{
					case 0:
						for(int j=0;j<3;j++)
						{
							str+="��"+j+"��:"+sp.scoreSchool[j+1]+"  �÷�:"+sp.score[j]+"\n";
						}
						break;
					case 1:
						for(int j=0;j<5;j++)
						{
							str+="��"+j+"��:"+sp.scoreSchool[j+1]+"  �÷�:"+sp.score[j]+"\n";
						}
						break;
				}
				
			}
			for(int i=0;i<Constant.listSportsProjectFemale.size();i++)
			{
				SportsProject sp=Constant.listSportsProjectFemale.get(i);
				str+="��Ŀ���:"+(Constant.listSportsProjectMale.size()+i)+"   "+"��Ŀ����:"+sp.name+"\n";
				int index=sp.scoreSchool[0];
				switch(index)
				{
					case 0:
						for(int j=0;j<3;j++)
						{
							str+="��"+j+"��:"+sp.scoreSchool[j+1]+"  �÷�:"+sp.score[j]+"\n";
						}
						break;
					case 1:
						for(int j=0;j<5;j++)
						{
							str+="��"+j+"��:"+sp.scoreSchool[j+1]+"  �÷�:"+sp.score[j]+"\n";
						}
						break;
				}
			}
			str+="=======================ѧУ��Ϣ======================\n";
			for(int i=0;i<Constant.listSchool.size();i++)
			{
				School school=Constant.listSchool.get(i);
				str+="ѧУ���:"+i+"  ѧУ����:"+school.name+"  ѧУ�ܷ�"+school.score+"   ������Ŀ�ܷ�="+school.maleScore+"    Ů����Ŀ�ܷ�"+school.femaleScore+"\n";
			}
			FileUtil.write(filePath, str, false);
			FileUtil.write(filePath, jaSort.getText(), true);
			
		}
	}
	
	public void itemStateChanged(ItemEvent e)
	{
		if(e.getSource()==jrbSort[0])
		{
			ccsu.sortSchoolId();
		}
		else if(e.getSource()==jrbSort[1])
		{
			ccsu.sortSchoolScore();
		}else if(e.getSource()==jrbSort[2])
		{
			ccsu.sortSchoolMaleScore();
		}else if(e.getSource()==jrbSort[3])
		{
			ccsu.sortSchoolFemaleScore();
		}
		

	}
	
	public void calculate()
	{
		for(School school:Constant.listSchool)
		{
			ccsu.sumSchoolScore(school);
		}
		 ccsu.sortSchoolScore();
	}

}
