package com.hk;

import java.util.HashSet;
import java.util.SortedSet;
import java.util.TreeSet;

public class Testing {
	public int countSchool;
	public int countMale;
	public int countFemale;
	
	public Testing(int countSchool,int countMale,int countFemale)
	{
		this.countSchool=countSchool;
		this.countMale=countMale;
		this.countFemale=countFemale;
	}
	
	public void initRandom()
	{
		randomMale();
		randomFemale();
		randomSchool();
	}
	
	public void randomMale()
	{
		for(int j=0;j<countMale;j++)
		{
			int [] scoreSchool=new int[6];
			int [] score=new int [5];
			scoreSchool[0]=(int)Math.floor(Math.random()*2);
			
			HashSet<Integer> schoolSet=new HashSet<Integer>();
			SortedSet<Integer> scoreSet=new TreeSet<Integer>();
			if(scoreSchool[0]==0){
				randomSet(0,countSchool,3,schoolSet);
				randomSet(0,100,3,scoreSet);
			}else{
				randomSet(0,countSchool,5,schoolSet);
				randomSet(0,100,5,scoreSet);
			}
			int i=1;
			for(int n:schoolSet)
			{
				scoreSchool[i]=n;
				
				i++;
			}
			
			if(scoreSchool[0]==0){i=2;}else{i=4;}
			for(int m:scoreSet)
			{
				score[i]=m;
				i--;
			}
				
			SportsProject sp=new SportsProject(j,"��Ŀ(��)"+j,scoreSchool,score);
			Constant.listSportsProjectMale.add(sp);
		}
	}
	
	public void randomFemale()
	{
		for(int j=0;j<countFemale;j++)
		{
			int [] scoreSchool=new int[6];
			int [] score=new int [5];
			scoreSchool[0]=(int)Math.floor(Math.random()*2);
			
			HashSet<Integer> schoolSet=new HashSet<Integer>();
			SortedSet<Integer> scoreSet=new TreeSet<Integer>();
			
			if(scoreSchool[0]==0){
				randomSet(0,countSchool,3,schoolSet);
				randomSet(0,100,3,scoreSet);
			}else{
				randomSet(0,countSchool,5,schoolSet);
				randomSet(0,100,5,scoreSet);
			}
			int i=1;
			
			for(int n:schoolSet)
			{
				scoreSchool[i]=n;
				
				i++;
			}
			
			if(scoreSchool[0]==0){i=2;}else{i=4;}
			for(int m:scoreSet)
			{
				score[i]=m;
				i--;
			}
				
			SportsProject sp=new SportsProject(j,"��Ŀ(Ů)"+j,scoreSchool,score);
			Constant.listSportsProjectFemale.add(sp);
		}
	}
	
	public void randomSchool()
	{	
		for(int i=0;i<countSchool;i++)
		{
			int score=0;
			int maleScore=0;
			int femaleScore=0;
			
			CalculateScoreUtil cs=new CalculateScoreUtil();
			maleScore=cs.sumSchoolMaleScore(i);
			femaleScore=cs.sumSchoolFemaleScore(i);
			score=maleScore+femaleScore;
			
			School s=new School(i,"ѧУ"+i,score,maleScore,femaleScore);
			Constant.listSchool.add(s);
		}
	}
	
   public static void randomSet(int min, int max, int n, HashSet<Integer> set) {
       if (n > (max - min + 1) || max < min) {  
           return;  
       }  
       for (int i = 0; i < n; i++) {  
           // ����Math.random()����  
           int num = (int) (Math.random() * (max - min)) + min;  
           set.add(num);// ����ͬ��������HashSet��  
       }  
       int setSize = set.size(); 
       // ����������С��ָ�����ɵĸ���������õݹ�������ʣ�����������������ѭ����ֱ���ﵽָ����С  
       if (setSize <n) {  
        randomSet(min, max, n - setSize, set);// �ݹ�  
       }  
   }
   
   public static void randomSet(int min, int max, int n, SortedSet<Integer> set) {
       if (n > (max - min + 1) || max < min) {  
           return;  
       }  
       for (int i = 0; i < n; i++) {  
           // ����Math.random()����  
           int num = (int) (Math.random() * (max - min)) + min;  
           set.add(num);// ����ͬ��������HashSet��  
       }  
       int setSize = set.size(); 
       // ����������С��ָ�����ɵĸ���������õݹ�������ʣ�����������������ѭ����ֱ���ﵽָ����С  
       if (setSize <n) {  
        randomSet(min, max, n - setSize, set);// �ݹ�  
       }  
   }
   
   
//   public static HashSet<Integer> random(int min,int max,int n)
//   {
//	   HashSet<Integer> set=new HashSet<Integer>();
//	   randomSet(min,max,n,set);
//	   return set;
//   }
}
