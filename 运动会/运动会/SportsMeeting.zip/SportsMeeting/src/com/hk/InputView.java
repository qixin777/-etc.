package com.hk;

import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;
import com.hk.Constant;

import javax.swing.JButton;

public class InputView extends JFrame implements ActionListener{

	static boolean schoolBool=false;
	static boolean maleBool=false;
	static boolean femaleBool=false;
	
	JButton bok=new JButton("�������");
	JLabel jlCSchool=new JLabel("ѧУ����");
	JLabel jlCMale=new JLabel("������Ŀ��");
	JLabel jlCFemale=new JLabel("Ů����Ŀ��");
	JTextField jtfCSchool=new JTextField();
	JTextField jtfCMale=new JTextField();
	JTextField jtfCFemale=new JTextField();
	
	public InputView()
	{
		this.setTitle("�˶������ͳ��ϵͳ");
		
		bok.setBounds(140,250,120,40);
		jlCSchool.setBounds(50,100,100,20);
		jlCMale.setBounds(50,150,100,20);
		jlCFemale.setBounds(50,200,100,20);
		jtfCSchool.setBounds(150,100,100,20);
		jtfCMale.setBounds(150,150,100,20);
		jtfCFemale.setBounds(150,200,100,20);
		
		this.add(bok);
		this.add(jlCSchool);
		this.add(jlCMale);
		this.add(jlCFemale);
		this.add(jtfCSchool);
		this.add(jtfCMale);
		this.add(jtfCFemale);
		
		bok.addActionListener(this);
		this.setLayout(null);
		this.setBounds(100,100,400,400);
		this.setVisible(true);
		this.setResizable(false);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==bok)
		{
			int countSchool=0;
			int countMale=0;
			int countFemale=0;
			
			Constant.listSchool=new ArrayList<School>();
			Constant.listSportsProjectMale=new ArrayList<SportsProject>();
			Constant.listSportsProjectFemale=new ArrayList<SportsProject>();
			
			if(jtfCSchool.getText().trim()!=""&&jtfCSchool.getText().trim()!=null)
			{
				try{
					countSchool=Integer.parseInt(jtfCSchool.getText().trim());
					if(countSchool>20||countSchool<0)
					{
						throw new Exception();
					}
					schoolBool=true;
				}catch(Exception exception)
				{
					schoolBool=false;
					maleBool=false;
					femaleBool=false;
					System.out.println("alert");
				}
			}
			
			if(jtfCMale.getText().trim()!=""&&jtfCMale.getText().trim()!=null)
			{
				try{
					countMale=Integer.parseInt(jtfCMale.getText().trim());
					if(countMale>20||countMale<0)
					{
						throw new Exception();
					}
					maleBool=true;
				}catch(Exception exception)
				{
					schoolBool=false;
					maleBool=false;
					femaleBool=false;
					System.out.println("alert");
				}
			}
			
			if(jtfCFemale.getText().trim()!=""&&jtfCFemale.getText().trim()!=null)
			{
				try{
					countFemale=Integer.parseInt(jtfCFemale.getText().trim());
					if(countFemale>20||countFemale<0)
					{
						throw new Exception();
					}
					femaleBool=true;
				}catch(Exception exception)
				{
					schoolBool=false;
					maleBool=false;
					femaleBool=false;
					System.out.println("alert");
				}
			}
			
			if(schoolBool&&maleBool&&femaleBool)
			{
				Testing test=new Testing(countSchool,countMale,countFemale);
				test.initRandom();
			}
		}
	}
	
	public static void main(String args[])
	{	
		InputView iv=new InputView();
		
		new Thread(){
			@Override
			public void run(){
				while(true)
				{
					try
					{
						sleep(100);
					}catch(Exception e)
					{
						e.printStackTrace();
					}
					
					if(schoolBool&&femaleBool&&maleBool)
					{
						
						new OutputView();
						iv.setVisible(false);
						break;
					}
				}

			}
		}.start();
	}
}
