package com.hk;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class CalculateScoreUtil {

	//ѧУ�ֺܷϼ�
	public void sumSchoolScore(School school)
	{
		int score=0;
		sumSchoolMaleScore(school);
		sumSchoolFemaleScore(school);
		score=school.getMaleScore()+school.getFemaleScore();
		
		school.score=score;
	}
	
	//ѧУ�ֺܷϼ�
	public int sumSchoolScore(int num)
	{
		int score=0;
		int male=sumSchoolMaleScore(num);
		int female=sumSchoolFemaleScore(num);
		score=male+female;
		
		return score;
	}
	
	//ѧУ�����ֺܷϼ�
	public void sumSchoolMaleScore(School school)
	{
		int score=0;
		int num=school.getNum();
		for(int i=0;i<Constant.listSportsProjectMale.size();i++)
		{
			int length=Constant.listSportsProjectMale.get(i).scoreSchool.length;
			for(int j=1;j<length;j++)
			{
				if(num==Constant.listSportsProjectMale.get(i).scoreSchool[j])
				{
					int add=0;
					if(Constant.listSportsProjectMale.get(i).scoreSchool[0]==0)
					{
						switch(j)
						{
							case 1:add=5;break;
							case 2:add=3;break;
							case 3:add=1;break;
						}
					}
					else if(Constant.listSportsProjectMale.get(i).scoreSchool[0]==1)
					{
						switch(j)
						{
							case 1:add=7;break;
							case 2:add=5;break;
							case 3:add=3;break;
							case 4:add=2;break;
							case 5:add=1;break;
						}
					}
					score+=add;
				}
			}
		}
		
		
		school.maleScore=score;
	}
	
	public int sumSchoolMaleScore(int num)
	{
		int score=0;
		for(int i=0;i<Constant.listSportsProjectMale.size();i++)
		{
			
			int length=Constant.listSportsProjectMale.get(i).scoreSchool.length;
			for(int j=1;j<length;j++)
			{
				if(num==Constant.listSportsProjectMale.get(i).scoreSchool[j])
				{
					int add=0;
					if(Constant.listSportsProjectMale.get(i).scoreSchool[0]==0)
					{
						switch(j)
						{
							case 1:add=5;break;
							case 2:add=3;break;
							case 3:add=1;break;
						}
					}
					else if(Constant.listSportsProjectMale.get(i).scoreSchool[0]==1)
					{
						switch(j)
						{
							case 1:add=7;break;
							case 2:add=5;break;
							case 3:add=3;break;
							case 4:add=2;break;
							case 5:add=1;break;
						}
					}
					score+=add;
				}
			}
		}
		
		
		return score;
	}
	
	//ѧУŮ���ֺܷϼ�
	public void sumSchoolFemaleScore(School school)
	{
		int score=0;
		int num=school.getNum();
		for(int i=0;i<Constant.listSportsProjectFemale.size();i++)
		{
			int length=Constant.listSportsProjectFemale.get(i).scoreSchool.length;
			for(int j=1;j<length;j++)
			{
				if(num==Constant.listSportsProjectFemale.get(i).scoreSchool[j])
				{
					int add=0;
					if(Constant.listSportsProjectFemale.get(i).scoreSchool[1]==0)
					{
						switch(j)
						{
							case 1:add=5;break;
							case 2:add=3;break;
							case 3:add=1;break;
						}
					}
					else if(Constant.listSportsProjectFemale.get(i).scoreSchool[1]==1)
					{
						switch(j)
						{
							case 1:add=7;break;
							case 2:add=5;break;
							case 3:add=3;break;
							case 4:add=2;break;
							case 5:add=1;break;
						}
					}
					score+=add;
				}
			}
		}
		
		
		school.femaleScore=score;
	}
	
	//ѧУŮ���ֺܷϼ�
		public int sumSchoolFemaleScore(int num)
		{
			int score=0;
			for(int i=0;i<Constant.listSportsProjectFemale.size();i++)
			{
				int length=Constant.listSportsProjectFemale.get(i).scoreSchool.length;
				for(int j=1;j<length;j++)
				{
					if(num==Constant.listSportsProjectFemale.get(i).scoreSchool[j])
					{
						int add=0;
						if(Constant.listSportsProjectFemale.get(i).scoreSchool[1]==0)
						{
							switch(j)
							{
								case 1:add=5;break;
								case 2:add=3;break;
								case 3:add=1;break;
							}
						}
						else if(Constant.listSportsProjectFemale.get(i).scoreSchool[1]==1)
						{
							switch(j)
							{
								case 1:add=7;break;
								case 2:add=5;break;
								case 3:add=3;break;
								case 4:add=2;break;
								case 5:add=1;break;
							}
						}
						score+=add;
					}
				}
			}
			
			
			return score;
		}
	
	//���������
	public void sortSchoolId()
	{
		Collections.sort(Constant.listSchool,new SchoolComparator(0));
	}
	//���ܷ�����
	public void sortSchoolScore()
	{
		Collections.sort(Constant.listSchool,new SchoolComparator(1));
	}
	
	//������������
	public void sortSchoolMaleScore()
	{
		Collections.sort(Constant.listSchool,new SchoolComparator(2));
	}
	
	//��Ů��������
	public void sortSchoolFemaleScore()
	{
		Collections.sort(Constant.listSchool,new SchoolComparator(3));
	}
}
