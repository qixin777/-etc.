package com.hk;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class CardProView extends JFrame implements ActionListener,ItemListener{
	
	int ibz=0;
	JButton bbefore=new JButton("��һ��");
	JButton bafter=new JButton("��һ��");
	List<JPanel> listPanel=new ArrayList<JPanel>();
	JPanel jp=new JPanel();
	CardLayout cl=new CardLayout();
	
	JButton bok=new JButton("������Ϣ");
	
	JLabel jlid;
	JLabel jlname;
	JLabel jlschoolId;
	JLabel jlschoolScore;
	JTextField jtfname;
	JTextField[] jtf_1;
	JTextField[] jtf_2;
	JRadioButton jrb3;
	JRadioButton jrb5;
	ButtonGroup jbg;
	
	public CardProView()
	{
		this.setTitle("�˶�����Ŀ��Ϣ����");
		
		for(int i=0;i<Constant.listSportsProjectMale.size()+Constant.listSportsProjectFemale.size();i++)
		{
			jlid=new JLabel("��Ŀ���:   "+i);
			jlname=new JLabel("��Ŀ����:");
			jtfname=new JTextField("��Ŀ"+i);
			jlschoolId=new JLabel("ѧУ���");
			jlschoolScore=new JLabel("ѧУ��Ŀ����");
			
			jrb3=new JRadioButton("ѡ��ǰ�����л���");
			jrb5=new JRadioButton("ѡ��ǰ����л���");
			jtf_1=new JTextField[5];
			jtf_2=new JTextField[5];
			for(int j=0;j<5;j++)
			{
				jtf_1[j]=new JTextField("0");
				jtf_2[j]=new JTextField("0");
			}
			jbg=new ButtonGroup();
			
			JPanel p=new JPanel();
			
			p.setLayout(null);

			jlid.setBounds(50,30,100,20);
			jlname.setBounds(50,80,100,20);
			jlschoolId.setBounds(335,20,100,20);
			jlschoolScore.setBounds(420,20,100,20);

			jtfname.setBounds(115,90, 100, 20);
			jrb3.setBounds(50,130,150,20);
			jrb5.setBounds(50,170,150,20);
			
			if(i<Constant.listSportsProjectMale.size())
			{
				jtfname.setText(Constant.listSportsProjectMale.get(i).getName());
			}else{
				jtfname.setText(Constant.listSportsProjectFemale.get(i-Constant.listSportsProjectMale.size()).getName());
			}
			
			jrb3.setSelected(true);
			
			p.add(jlid);		//0
			p.add(jtfname);		//1
			p.add(jlname);		//2
			p.add(jrb3);		//3
			p.add(jrb5);		//4
			p.add(jlschoolId);	//5
			p.add(jlschoolScore);//6
			
			for(int j=0;j<5;j++)
			{
				jtf_1[j].setBounds(320,50+30*j,80,20);
				jtf_2[j].setBounds(420,50+30*j,80,20);
				p.add(jtf_1[j]);//7-11
				p.add(jtf_2[j]);//12-16
			}
			jtf_1[3].setEditable(false);
			jtf_1[4].setEditable(false);
			jtf_2[3].setEditable(false);
			jtf_2[4].setEditable(false);
			
			jbg.add(jrb3);
			jbg.add(jrb5);

			jrb3.addItemListener(this);
			jrb5.addItemListener(this);

			listPanel.add(p);
		}
		
		jp.setLayout(cl);
		jp.setBounds(10, 10, 600,200);
		
		for(int j=0;j<listPanel.size();j++)
		{
			jp.add(listPanel.get(j),""+j);
		}
		
		bbefore.setBounds(50, 220, 100, 20);
		bafter.setBounds(200, 220, 100, 20);
		bok.setBounds(50, 260, 250, 20);
		this.add(bbefore);
		this.add(bafter);
		this.add(bok);
		bbefore.addActionListener(this);
		bafter.addActionListener(this);
		bok.addActionListener(this);

		
		this.add(jp);
		this.setLayout(null);
		this.setBounds(300,200,600,350);
		this.setVisible(true);
		this.setResizable(false);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		int ijg=Constant.listSportsProjectFemale.size()+Constant.listSportsProjectMale.size();
		if(e.getSource()==bbefore)
		{
			cl.previous(jp);
			ibz--;
			if(ibz==0)
			{
				bbefore.setEnabled(false);
			}else
			{
				bafter.setEnabled(true);
			}
		}else if(e.getSource()==bafter)
		{
			cl.next(jp);
			ibz++;
			if(ibz==ijg-1)
			{
				bafter.setEnabled(false);
			}else
			{
				bbefore.setEnabled(true);
			} 
		}else if(e.getSource()==bok)
		{
			for(int i=0;i<Constant.listSportsProjectMale.size();i++){
				Object obj1=listPanel.get(i).getComponent(1);
				if(obj1 instanceof JTextField)
				{
					 Constant.listSportsProjectMale.get(i).setName(((JTextField) obj1).getText());
				}
				Object obj2=listPanel.get(i).getComponent(3);
				if(obj2 instanceof JRadioButton)
				{
					if(((JRadioButton)obj2).isSelected())
					{
						Constant.listSportsProjectMale.get(i).scoreSchool[0]=0;
					}else{
						Constant.listSportsProjectMale.get(i).scoreSchool[0]=1;
					}
				}
				Object[] objjtf=new Object[10];
				for(int j=7;j<=16;j+=2)
				{
					objjtf[j-7]=listPanel.get(i).getComponent(j);
					objjtf[j+1-7]=listPanel.get(i).getComponent(j+1);
					if(objjtf[j-7] instanceof JTextField&&objjtf[j-7+1] instanceof JTextField)
					{
						try
						{
							Constant.listSportsProjectMale.get(i).scoreSchool[(j-7)/2+1]=Integer.parseInt(((JTextField)objjtf[j-7]).getText().trim());
							Constant.listSportsProjectMale.get(i).score[(j-7)/2]=Integer.parseInt(((JTextField)objjtf[j+1-7]).getText().trim());
						}catch(Exception exception)
						{
							System.out.println("�����ʽ����");
						}						
					}
				}
			}
			this.dispose();
			new OutputView();
		}
	}
	
	public void itemStateChanged(ItemEvent e)
	{
		Object jrb1=listPanel.get(ibz).getComponent(3);
		Object jrb2=listPanel.get(ibz).getComponent(4);
		JRadioButton jrb_3;
		JRadioButton jrb_5;
		if(jrb1 instanceof JRadioButton&&jrb2 instanceof JRadioButton)
		{
			jrb_3=(JRadioButton)jrb1;
			jrb_5=(JRadioButton)jrb2;
			
			if(e.getSource()==jrb_3)
			{
				Object obj1=listPanel.get(ibz).getComponent(13);
				Object obj2=listPanel.get(ibz).getComponent(14);
				Object obj3=listPanel.get(ibz).getComponent(15);
				Object obj4=listPanel.get(ibz).getComponent(16);
				
				if(obj1 instanceof JTextField)
				{
					System.out.println("111");
					((JTextField)obj1).setEditable(false);
				}
				if(obj2 instanceof JTextField)
				{
					((JTextField)obj2).setEditable(false);
				}
				if(obj3 instanceof JTextField)
				{
					((JTextField)obj3).setEditable(false);
				}
				if(obj4 instanceof JTextField)
				{
					((JTextField)obj4).setEditable(false);
				}
			}else if(e.getSource()==jrb_5)
			{
				Object obj1=listPanel.get(ibz).getComponent(13);
				Object obj2=listPanel.get(ibz).getComponent(14);
				Object obj3=listPanel.get(ibz).getComponent(15);
				Object obj4=listPanel.get(ibz).getComponent(16);
				if(obj1 instanceof JTextField)
				{
					((JTextField)obj1).setEditable(true);
				}
				if(obj2 instanceof JTextField)
				{
					((JTextField)obj2).setEditable(true);
				}
				if(obj3 instanceof JTextField)
				{
					((JTextField)obj3).setEditable(true);
				}
				if(obj4 instanceof JTextField)
				{
					((JTextField)obj4).setEditable(true);
				}
			}
		}
		
	}
}
