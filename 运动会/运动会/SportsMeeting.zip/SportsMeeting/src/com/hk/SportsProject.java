package com.hk;

import java.util.List;
import java.util.ArrayList;

public class SportsProject {
	int num;//��Ŀ���
	String name;//��Ŀ����
	int [] scoreSchool;//ǰ�������
	int [] score;//ǰ�����÷�
	
	public SportsProject(int num,String name,int []scoreSchool,int[] score)
	{
		this.num=num;
		this.name=name;
		this.scoreSchool=scoreSchool;
		this.score=score;
	}
	public SportsProject(String name)
	{
		this.name=name;
		scoreSchool=new int[6];
		score=new int[5];
	}
	
	public String getName()
	{
		return name;
	}
	
	public void setName(String name)
	{
		this.name=name;
	}

	public int getNum()
	{
		return num;
	}
	
	public void setNum(int num)
	{
		this.num=num;
	}
	
	public int[] getScoreSchool()
	{
		return scoreSchool;
	}
	
	public void setScoreSchool(int [] scoreSchool)
	{
		this.scoreSchool=scoreSchool;
	}
	
	public void setScore(int [] score)
	{
		this.score=score;
	}
	
	public int[] getScore()
	{
		return score;
	}
}
