package com.hk;

import java.util.ArrayList;
import java.util.List;

public class Constant {
	public static List<School> listSchool;
	public static List<SportsProject> listSportsProjectMale;
	public static List<SportsProject> listSportsProjectFemale;
}
