package com.hk;

public class School{
	int num;//���
	String name;//ѧУ����
	int score;//ѧУ�ܷ�
	int maleScore;//�����ܷ�
	int femaleScore;//Ů���ܷ�
	
	public School(int num,String name,int score,int maleScore,int femaleScore)
	{
		this.num=num;
		this.name=name;
		this.score=score;
		this.maleScore=maleScore;
		this.femaleScore=femaleScore;
	}
	
	public School(String name)
	{
		this.name=name;
		score=0;
		maleScore=0;
		femaleScore=0;
	}
	
	public void setNum(int num)
	{
		this.num=num;
	}
	
	public void setScore(int score)
	{
		this.score=score;
	}
	
	public void setMaleScore(int maleScore)
	{
		this.maleScore=maleScore;
	}
	
	public void setFemaleScore(int femaleScore)
	{
		this.femaleScore=femaleScore;
	}
	
	public int getNum()
	{
		return num;
	}
	
	public String getString()
	{
		return name;
	}
	
	public int getScore()
	{
		return score;
	}
	
	public int getMaleScore()
	{
		return maleScore;
	}
	
	public int getFemaleScore()
	{
		return femaleScore;
	}
	
}
